# Install
install.packages("tm")  # for text mining
install.packages("SnowballC") # for text stemming
install.packages("wordcloud") # word-cloud generator 
install.packages("RColorBrewer") # color palettes


# Load
library("tm")
library("SnowballC")
library("wordcloud")
library("RColorBrewer")


# Reading and loading the data set

tweets = read.csv("analytics _scores.csv", stringsAsFactors=FALSE)

str(tweets)


# Loading the data in corpus

corpus = Corpus(VectorSource(tweets))


# Checking content of the corpus

corpus = Corpus(VectorSource(tweets$text))


inspect(corpus)


# Text transformation

toSpace = content_transformer(function (x, pattern ) gsub(pattern," ",x))

corpus = tm_map(corpus,toSpace, "/")

corpus = tm_map(corpus,toSpace, "@")

corpus = tm_map(corpus,toSpace, "\\|")

# convert the text to lower case

corpus = tm_map(corpus,content_transformer(tolower))


# Text cleaning

corpus = tm_map(corpus,removeNumbers)

corpus = tm_map(corpus,removeWords,c("https","tco",stopwords("english")))

corpus = tm_map(corpus,removePunctuation)

corpus = tm_map(corpus,stripWhitespace)


# term-document matrix


frequencies = TermDocumentMatrix(corpus)

m <- as.matrix(dtm)
v <- sort(rowSums(m),decreasing=TRUE)
d <- data.frame(word = names(v),freq=v)
head(d, 10)

# create word cloud 

set.seed(1234)

wordcloudanalytics = wordcloud(words = d$word, freq = d$freq, min.freq = 1,
          max.words=200, random.order=FALSE, rot.per=0.35, 
          colors=brewer.pal(8, "Dark2"))


# word cloud sentiment
wordcloudsentiment = wordcloud(words = d$word, freq = d$freq, min.freq = 1,
max.words=200, random.order=FALSE, rot.per=0.35,
colors=colors)


